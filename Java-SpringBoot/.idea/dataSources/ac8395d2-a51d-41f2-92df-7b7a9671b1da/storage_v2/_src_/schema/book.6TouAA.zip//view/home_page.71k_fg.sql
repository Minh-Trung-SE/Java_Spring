create view home_page as
select `book`.`book_category`.`category_name` AS `category_name`, `book`.`book_storage`.`book_title` AS `book_title`
from (`book`.`book_category`
         join `book`.`book_storage` on ((`book`.`book_category`.`category_id` = `book`.`book_storage`.`category_id`)));


create view user_page_2 as
select `book`.`book_storage`.`link_photo`   AS `Link photo`,
       `book`.`book_storage`.`book_title`   AS `Book title`,
       `book`.`book_post`.`date`            AS `Date post`,
       `book`.`book_storage`.`release_year` AS `Release year`,
       `book`.`book_storage`.`price`        AS `Price`,
       `book`.`book_storage`.`amount`       AS `Amount`,
       `book`.`users`.`user_phone`          AS `Phone user post`
from ((`book`.`book_post` join `book`.`users` on ((`book`.`book_post`.`user_phone` = `book`.`users`.`user_phone`)))
         join `book`.`book_storage` on ((`book`.`book_post`.`book_id` = `book`.`book_storage`.`book_id`)))
where (`book`.`book_post`.`user_phone` = 123456789);


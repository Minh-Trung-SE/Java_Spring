create view user_page_3 as
select `book`.`book_storage`.`link_photo`   AS `Link photo`,
       `book`.`book_storage`.`book_title`   AS `Book title`,
       `book`.`users`.`user_phone`          AS `Phone user post`,
       `book`.`book_storage`.`release_year` AS `Release year`,
       `book`.`book_storage`.`price`        AS `Price`
from ((`book`.`book_favourite` join `book`.`book_storage` on ((`book`.`book_favourite`.`book_id` = `book`.`book_storage`.`book_id`)))
         join `book`.`users` on ((`book`.`book_favourite`.`user_phone` = `book`.`users`.`user_phone`)))
where (`book`.`book_favourite`.`user_phone` = 335840115);

